__MODULE__ = "𝙲𝙾𝙻𝙾𝙽𝙶"
__HELP__ = """
<blockquote><b>Bantuan Untuk Colong

perintah : <code>{0}colong</code>
Untuk Mengambil Media/vidio Yang 1x Lihat</b></blockquote>
"""
